const SUPABASE_URL = "https://eyydjfdujxysaixmgfnb.supabase.co";
const SUPABASE_KEY = "sb_publishable_16ZF9RTPcE8zo2viuLRFdw_tKAXqX7X";

const supabaseLib = window.supabase;
const supabaseClient = supabaseLib.createClient(SUPABASE_URL, SUPABASE_KEY);
window.supabase = supabaseClient;

const CART_STORAGE_KEY = 'legrand_cart';
const USER_STORAGE_KEY = 'legrand_user';

function getCart() {
    return JSON.parse(localStorage.getItem(CART_STORAGE_KEY) || '[]');
}

function setCart(cart) {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
}

function getUserData() {
    return JSON.parse(localStorage.getItem(USER_STORAGE_KEY) || 'null');
}

function setUserData(user) {
    localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
}

function clearUserData() {
    localStorage.removeItem(USER_STORAGE_KEY);
}
