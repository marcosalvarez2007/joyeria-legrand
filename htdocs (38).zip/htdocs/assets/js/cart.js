  const CART_KEY = 'legrand_cart';
const DEFAULT_PRODUCT_IMAGE = 'https://images.unsplash.com/photo-1495121605193-b116b5b9c5d0?auto=format&fit=crop&w=900&q=80';

function normalizeCartImage(src) {
    const image = String(src || '').trim();
    if (!image || image.includes('picsum.photos') || image.includes('placeholder.com') || image.includes('plant') || image.includes('tree') || image.includes('leaf')) {
        return DEFAULT_PRODUCT_IMAGE;
    }
    return image;
}

const PAYMENT_OPTIONS = {
    mercadopago: { label: 'Mercado Pago', description: 'Pago online seguro con tarjetas y transferencia.', discount: 0 },
    transferencia: { label: 'Transferencia bancaria', description: 'Recibe 30% de descuento. Confirma el pago por WhatsApp.', discount: 0.30 },
    efectivo: { label: 'Pago en efectivo', description: 'Retira en tienda y obtén 30% de descuento.', discount: 0.30 }
};
let selectedPaymentMethod = 'mercadopago';

function normalizeImage(src) {
    if (typeof src !== 'string' || !src.trim()) return DEFAULT_PRODUCT_IMAGE;
    return src.includes('picsum.photos') ? DEFAULT_PRODUCT_IMAGE : src;
}

function normalizeProduct(product) {
    if (!product || typeof product !== 'object') return null;
    return {
        ...product,
        id: Number(product.id),
        cantidad: Number(product.cantidad) || 1,
        imagenes: Array.isArray(product.imagenes) && product.imagenes.length
            ? product.imagenes.map(normalizeCartImage)
            : [DEFAULT_PRODUCT_IMAGE]
    };
}

function normalizeCartItems(items) {
    if (!Array.isArray(items)) return [];
    return items.map(normalizeProduct).filter(Boolean);
}

function getCartItems() {
    return normalizeCartItems(JSON.parse(localStorage.getItem(CART_KEY) || '[]'));
}

function setCartItems(items) {
    localStorage.setItem(CART_KEY, JSON.stringify(items));
}

function updateCartCount() {
    const count = getCartItems().reduce((sum, item) => sum + (item.cantidad || 1), 0);
    document.querySelectorAll('#cart-count').forEach(el => el.textContent = count);
}

function getPaymentDiscount() {
    return PAYMENT_OPTIONS[selectedPaymentMethod]?.discount || 0;
}

function formatAmount(amount) {
    return Number(amount).toFixed(2);
}

function renderPaymentOptions() {
    const container = document.getElementById('payment-options');
    if (!container) return;
    container.innerHTML = Object.entries(PAYMENT_OPTIONS).map(([key, option]) => {
        const activeClass = key === selectedPaymentMethod ? 'payment-option selected' : 'payment-option';
        return `
            <div class="${activeClass}" onclick="selectPaymentMethod('${key}')">
                <h4>${option.label}</h4>
                <p>${option.description}</p>
                ${option.discount > 0 ? `<strong>${option.discount * 100}% de descuento</strong>` : ''}
            </div>
        `;
    }).join('');
}

function calculateTotals(items) {
    const baseTotal = items.reduce((sum, item) => sum + Number(item.precio) * (item.cantidad || 1), 0);
    const discount = getPaymentDiscount();
    const discountAmount = baseTotal * discount;
    const finalTotal = baseTotal - discountAmount;
    return { baseTotal, discount, discountAmount, finalTotal };
}

function renderCart() {
    const items = getCartItems();
    const container = document.getElementById('cart-items');
    if (!container) return;

    renderPaymentOptions();

    if (!items.length) {
        container.innerHTML = `
            <div class="empty-cart">
                <h2>Tu carrito está vacío</h2>
                <p>Explora nuestra colección de joyas exclusivas y añade tus favoritas.</p>
                <a class="btn btn-primary" href="catalogo.html">Ver catálogo</a>
            </div>
        `;
        document.getElementById('subtotal').textContent = '0.00';
        document.getElementById('total').textContent = '0.00';
        updateCartCount();
        return;
    }

    let total = 0;
    container.innerHTML = items.map((item, index) => {
        const precio = Number(item.precio) * (item.cantidad || 1);
        total += precio;
        const imagen = Array.isArray(item.imagenes) && item.imagenes.length ? normalizeImage(item.imagenes[0]) : DEFAULT_PRODUCT_IMAGE;
        return `
            <div class="cart-item">
                <img src="${imagen}" alt="${item.nombre}">
                <div>
                    <h3>${item.nombre}</h3>
                    <p>${item.descripcion ? item.descripcion.substring(0, 80) + '...' : 'Pieza limitada'}</p>
                    <div class="cart-meta">
                        <span>Cantidad: ${item.cantidad || 1}</span>
                        <span>Precio: $${precio.toFixed(2)}</span>
                    </div>
                    <button type="button" class="btn-link" onclick="removeFromCart(${index})">Eliminar</button>
                </div>
            </div>
        `;
    }).join('');

    const totals = calculateTotals(items);
    document.getElementById('subtotal').textContent = formatAmount(totals.baseTotal);
    document.getElementById('total').textContent = formatAmount(totals.finalTotal);

    if (totals.discount > 0) {
        document.getElementById('discount-text').textContent = `Descuento aplicado: $${formatAmount(totals.discountAmount)} (${totals.discount * 100}%)`;
        document.getElementById('discount-text').style.display = 'block';
    } else {
        document.getElementById('discount-text').style.display = 'none';
    }

    updateCartCount();
}

function selectPaymentMethod(method) {
    if (!PAYMENT_OPTIONS[method]) return;
    selectedPaymentMethod = method;
    renderCart();
}

function removeFromCart(index) {
    const items = getCartItems();
    items.splice(index, 1);
    setCartItems(items);
    renderCart();
}

async function checkoutCart() {
    const items = getCartItems();
    if (!items.length) {
        return alert('Tu carrito está vacío. Añade una pieza antes de continuar.');
    }

    const { data: sessionData } = await supabase.auth.getSession();
    const user = sessionData?.session?.user || getUserData();
    if (!user) {
        alert('Debes iniciar sesión para completar la compra.');
        return window.location.href = 'login.html';
    }

    openCheckoutModal();
}

function openCheckoutModal() {
    // Pre-carga datos si ya los conocemos del perfil del usuario
    const user = getUserData();
    if (user) {
        const nombreCompleto = (user.full_name || user.user_metadata?.full_name || '').split(' ');
        if (nombreCompleto.length) {
            document.getElementById('chk-nombre').value = nombreCompleto[0] || '';
            document.getElementById('chk-apellido').value = nombreCompleto.slice(1).join(' ') || '';
        }
        document.getElementById('chk-email').value = user.email || '';
        document.getElementById('chk-direccion').value = user.address || user.user_metadata?.address || '';
    }
    document.getElementById('checkout-form-error').style.display = 'none';
    document.getElementById('checkout-modal').style.display = 'flex';
}

function closeCheckoutModal() {
    document.getElementById('checkout-modal').style.display = 'none';
}

async function confirmCheckout(comprador) {
    const items = getCartItems();
    const { data: sessionData } = await supabase.auth.getSession();
    const user = sessionData?.session?.user || getUserData();
    if (!user) {
        alert('Debes iniciar sesión para completar la compra.');
        return window.location.href = 'login.html';
    }

    const totals = calculateTotals(items);
    const metodoPago = PAYMENT_OPTIONS[selectedPaymentMethod]?.label || 'Mercado Pago';

    const orderResponse = await supabase.from('pedidos').insert([{
        usuario_id: user.id,
        total: totals.finalTotal,
        estado: 'pendiente',
        metodo_envio: metodoPago,
        direccion_envio: comprador.direccion,
        comprador_nombre: comprador.nombre,
        comprador_apellido: comprador.apellido,
        comprador_dni: comprador.dni,
        comprador_email: comprador.email
    }]).select('id').single();

    if (orderResponse.error) {
        console.error('Error creando pedido:', orderResponse.error);
        return alert('No se pudo crear el pedido: ' + orderResponse.error.message);
    }

    const orderId = orderResponse.data.id;
    const itemsPayload = items.map(item => ({ pedido_id: orderId, producto_id: item.id, cantidad: item.cantidad || 1, precio_unitario: Number(item.precio) }));
    await supabase.from('pedido_items').insert(itemsPayload);
    await supabase.from('pagos').insert([{ pedido_id: orderId, estado: 'pendiente', monto: totals.finalTotal, metodo: selectedPaymentMethod }]);

    // Si el método elegido es Mercado Pago, generamos la preferencia y redirigimos a pagar
    if (selectedPaymentMethod === 'mercadopago') {
        const errorBox = document.getElementById('checkout-form-error');
        const submitBtn = document.getElementById('checkout-submit-btn');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Redirigiendo a Mercado Pago...';
        try {
            const { data, error } = await supabase.functions.invoke('crear-preferencia-mp', {
                body: {
                    pedido_id: orderId,
                    items: items.map(item => ({ nombre: item.nombre, cantidad: item.cantidad || 1, precio: Number(item.precio) })),
                    comprador
                }
            });
            if (error || !data?.init_point) {
                throw new Error(error?.message || 'No se pudo generar el link de pago.');
            }
            setCartItems([]);
            updateCartCount();
            window.location.href = data.init_point;
            return;
        } catch (err) {
            console.error('Error generando preferencia de Mercado Pago:', err);
            errorBox.textContent = 'No se pudo iniciar el pago con Mercado Pago. Intenta nuevamente.';
            errorBox.style.display = 'block';
            submitBtn.disabled = false;
            submitBtn.textContent = 'Continuar';
            return;
        }
    }

    // Transferencia o efectivo: mismo flujo que antes (instrucciones por WhatsApp)
    setCartItems([]);
    updateCartCount();
    closeCheckoutModal();
    alert(`Pedido registrado. Total: $${formatAmount(totals.finalTotal)}. Recibirás instrucciones en WhatsApp para completar el pago con descuento.`);
    window.location.href = 'index.html';
}

function initCheckoutForm() {
    const form = document.getElementById('checkout-form');
    if (!form) return;
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const comprador = {
            nombre: document.getElementById('chk-nombre').value.trim(),
            apellido: document.getElementById('chk-apellido').value.trim(),
            dni: document.getElementById('chk-dni').value.trim(),
            email: document.getElementById('chk-email').value.trim(),
            direccion: document.getElementById('chk-direccion').value.trim()
        };
        const errorBox = document.getElementById('checkout-form-error');
        if (!comprador.nombre || !comprador.apellido || !comprador.dni || !comprador.email || !comprador.direccion) {
            errorBox.textContent = 'Completa todos los campos para continuar.';
            errorBox.style.display = 'block';
            return;
        }
        if (!/^\d{7,9}$/.test(comprador.dni)) {
            errorBox.textContent = 'Ingresa un DNI válido (solo números).';
            errorBox.style.display = 'block';
            return;
        }
        errorBox.style.display = 'none';
        confirmCheckout(comprador);
    });
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        renderCart();
        updateCartCount();
        initCheckoutForm();
    });
} else {
    renderCart();
    updateCartCount();
    initCheckoutForm();
}
