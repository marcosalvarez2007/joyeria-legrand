// User Profile Management

let currentUser = null;
let userData = null;
let isEditing = false;

// Initialize profile
async function initProfile() {
    try {
        const { data: { user } } = await supabase.auth.getUser();
        
        if (!user) {
            console.warn('No hay usuario autenticado');
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 500);
            return;
        }

        currentUser = user;
        console.log('Usuario autenticado:', user.email);
        
        // Load user info
        await loadUserProfile(user.id);
        
        // Setup event listeners
        setupEventListeners();
        
        // Setup user menu dropdown
        setupUserMenuDropdown();
        
        console.log('Perfil inicializado correctamente');
    } catch (error) {
        console.error('Error inicializando perfil:', error);
        // No mostrar alerta - dejar que se muestre el contenido aunque con datos básicos
    }
}

// Load user profile
async function loadUserProfile(userId) {
    try {
        console.log('Cargando perfil para usuario:', userId);
        
        const { data, error } = await supabase
            .from('usuarios')
            .select('*')
            .eq('id', userId)
            .single();

        if (error && error.code !== 'PGRST116') {
            // PGRST116 = no rows found, que es normal si el usuario es nuevo
            throw error;
        }

        if (!data) {
            console.log('Usuario no encontrado en tabla users, creando registro...');
            // Crear registro si no existe
            const user = currentUser;
            const fullName = user.user_metadata?.full_name || 'Usuario';
            const newUser = {
                id: userId,
                email: user.email,
                full_name: fullName,
                phone: user.user_metadata?.phone || '',
                address: user.user_metadata?.address || '',
                gender: user.user_metadata?.gender || '',
                birthday: user.user_metadata?.birthday || '',
                role: 'user',
                created_at: new Date().toISOString()
            };
            
            const { data: insertedData, error: insertError } = await supabase
                .from('usuarios')
                .insert([newUser])
                .select()
                .single();
            
            if (insertError) {
                console.error('Error creando usuario:', insertError);
                userData = newUser; // Usar los datos locales aunque falle la inserción
            } else {
                userData = insertedData;
            }
        } else {
            userData = data;
        }

        console.log('Datos del usuario cargados:', userData);
        // Actualizar display con datos reales
        displayUserInfo();
        
    } catch (error) {
        console.error('Error loading user profile:', error);
        // No lanzar error, continuar con los datos que tenemos
    }
}

// Display user information
function displayUserInfo() {
    try {
        if (!userData) {
            console.warn('userData es null');
            return;
        }

        // Profile section - con verificación de elementos
        const nameEl = document.getElementById('userName');
        if (nameEl) {
            nameEl.textContent = userData.full_name || 'Usuario';
        }

        const emailEl = document.getElementById('userEmail');
        if (emailEl) {
            emailEl.textContent = userData.email || 'No especificado';
        }

        const phoneEl = document.getElementById('userPhone');
        if (phoneEl) {
            phoneEl.textContent = userData.phone || 'No especificado';
        }

        const addressEl = document.getElementById('userAddress');
        if (addressEl) {
            addressEl.textContent = userData.address || 'No especificada';
        }

        const genderEl = document.getElementById('userGender');
        if (genderEl) {
            genderEl.textContent = userData.gender || 'No especificado';
        }

        const birthdayEl = document.getElementById('userBirthday');
        if (birthdayEl) {
            if (userData.birthday) {
                try {
                    birthdayEl.textContent = new Date(userData.birthday).toLocaleDateString('es-AR');
                } catch (e) {
                    birthdayEl.textContent = userData.birthday;
                }
            } else {
                birthdayEl.textContent = 'No especificado';
            }
        }

        // Dropdown menu - con verificación
        const dropdownNameEl = document.getElementById('dropdownName');
        if (dropdownNameEl) {
            dropdownNameEl.textContent = userData.full_name || 'Usuario';
        }

        const dropdownEmailEl = document.getElementById('dropdownEmail');
        if (dropdownEmailEl) {
            dropdownEmailEl.textContent = userData.email || 'No especificado';
        }

        console.log('Perfil cargado correctamente:', userData);
    } catch (error) {
        console.error('Error en displayUserInfo:', error);
    }
}

// Setup all page event listeners (edit button, password modal, logout, etc.)
function setupEventListeners() {
    try {
        const editBtn = document.getElementById('editProfileBtn');
        if (editBtn) {
            editBtn.addEventListener('click', toggleEditMode);
        }

        const changePasswordBtn = document.getElementById('changePasswordBtn');
        const changePasswordModal = document.getElementById('changePasswordModal');
        if (changePasswordBtn && changePasswordModal) {
            changePasswordBtn.addEventListener('click', () => {
                changePasswordModal.classList.add('active');
            });
        }

        if (changePasswordModal) {
            const closeBtn = changePasswordModal.querySelector('.modal-close');
            const cancelBtn = changePasswordModal.querySelector('.modal-footer .btn-secondary');
            [closeBtn, cancelBtn].forEach(btn => {
                if (btn) {
                    btn.addEventListener('click', () => {
                        changePasswordModal.classList.remove('active');
                        const form = document.getElementById('changePasswordForm');
                        if (form) form.reset();
                    });
                }
            });
        }

        const changePasswordForm = document.getElementById('changePasswordForm');
        if (changePasswordForm) {
            changePasswordForm.addEventListener('submit', changePassword);
        }

        const logoutLink = document.getElementById('logoutLink');
        if (logoutLink) {
            logoutLink.addEventListener('click', (e) => {
                e.preventDefault();
                logout();
            });
        }

        // Sidebar navigation: switch between profile sections
        const navItems = document.querySelectorAll('.profile-nav-item[data-section]');
        const sections = document.querySelectorAll('.profile-section');
        navItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = item.dataset.section;

                navItems.forEach(nav => nav.classList.remove('active'));
                item.classList.add('active');

                sections.forEach(sec => {
                    sec.classList.toggle('active', sec.id === targetId);
                });

                history.replaceState(null, '', '#' + targetId);
            });
        });

        // Show the section matching the current URL hash on load (e.g. perfil.html#privacidad)
        const initialHash = window.location.hash.replace('#', '');
        if (initialHash) {
            const initialNav = document.querySelector(`.profile-nav-item[data-section="${initialHash}"]`);
            if (initialNav) {
                initialNav.click();
            }
        }

        console.log('Event listeners configurados');
    } catch (error) {
        console.error('Error configurando event listeners:', error);
    }
}

// Toggle edit mode
function toggleEditMode() {
    try {
        isEditing = !isEditing;
        const profileCard = document.querySelector('.profile-card');
        const editBtn = document.getElementById('editProfileBtn');
        const detailGroups = document.querySelectorAll('.detail-group');
        
        if (!profileCard || !editBtn) {
            console.error('Elementos necesarios no encontrados');
            return;
        }

        if (isEditing) {
            // Modo edición
            editBtn.innerHTML = '<i class="fas fa-save"></i> Guardar Cambios';
            editBtn.style.background = '#28a745';
            profileCard.classList.add('edit-mode');
            
            // Hacer campos editables
            detailGroups.forEach(group => {
                const label = group.querySelector('label');
                const paragraph = group.querySelector('p');
                
                if (paragraph) {
                    const key = paragraph.id.replace('user', '').toLowerCase();
                    let value = '';
                    
                    if (key === 'phone') value = userData?.phone || '';
                    else if (key === 'address') value = userData?.address || '';
                    else if (key === 'gender') value = userData?.gender || '';
                    else if (key === 'birthday') value = userData?.birthday ? userData.birthday.split('T')[0] : '';
                    
                    let input;
                    if (key === 'address') {
                        // Para dirección usar textarea
                        input = document.createElement('textarea');
                        input.style.minHeight = '100px';
                        input.style.resize = 'vertical';
                    } else {
                        input = document.createElement('input');
                        input.type = key === 'birthday' ? 'date' : 'text';
                    }
                    
                    input.className = 'profile-edit-input';
                    input.value = value;
                    input.placeholder = key === 'address' ? 'Dirección completa' : label?.textContent || '';
                    input.dataset.key = key;
                    
                    paragraph.replaceWith(input);
                }
            });

            // También hacer editable el nombre
            const nameEl = document.getElementById('userName');
            if (nameEl && nameEl.tagName !== 'INPUT' && nameEl.tagName !== 'TEXTAREA') {
                const nameInput = document.createElement('input');
                nameInput.type = 'text';
                nameInput.className = 'profile-edit-input';
                nameInput.value = userData?.full_name || '';
                nameInput.dataset.key = 'full_name';
                nameInput.style.fontSize = '24px';
                nameInput.style.fontWeight = 'bold';
                nameInput.placeholder = 'Tu nombre completo';
                nameEl.replaceWith(nameInput);
                nameInput.id = 'userName';
            }
        } else {
            // Guardar cambios
            saveProfileChanges();
        }
    } catch (error) {
        console.error('Error toggling edit mode:', error);
        alert('Error al cambiar modo edición: ' + error.message);
    }
}

// Save profile changes
async function saveProfileChanges() {
    try {
        const updates = {};
        
        // Recopilar datos de inputs
        const nameInput = document.querySelector('input[data-key="full_name"]');
        if (nameInput) {
            updates.full_name = nameInput.value;
        }
        
        document.querySelectorAll('.profile-edit-input').forEach(input => {
            if (input.dataset.key && input.dataset.key !== 'full_name') {
                updates[input.dataset.key] = input.value;
            }
        });
        
        if (Object.keys(updates).length === 0) {
            console.log('No hay cambios para guardar');
            // Cancelar edición sin guardar
            isEditing = false;
            const editBtn = document.getElementById('editProfileBtn');
            if (editBtn) {
                editBtn.innerHTML = '<i class="fas fa-edit"></i> Editar';
                editBtn.style.background = '#667eea';
            }
            displayUserInfo();
            return;
        }
        
        if (!currentUser) {
            alert('Error: Usuario no autenticado');
            return;
        }
        
        // Actualizar en Supabase
        const { error } = await supabase
            .from('usuarios')
            .update(updates)
            .eq('id', currentUser.id);
        
        if (error) throw error;
        
        // Actualizar datos locales
        Object.assign(userData, updates);
        
        // Restaurar vista normal
        isEditing = false;
        const editBtn = document.getElementById('editProfileBtn');
        if (editBtn) {
            editBtn.innerHTML = '<i class="fas fa-edit"></i> Editar';
            editBtn.style.background = '#667eea';
        }
        
        const profileCard = document.querySelector('.profile-card');
        if (profileCard) {
            profileCard.classList.remove('edit-mode');
        }
        
        // Recargar la página para mostrar cambios
        displayUserInfo();
        alert('Perfil actualizado exitosamente');
        location.reload();
        
    } catch (error) {
        console.error('Error saving profile:', error);
        alert('Error al guardar cambios: ' + error.message);
    }
}

// Load purchase history

// Setup user menu dropdown
function setupUserMenuDropdown() {
    try {
        const trigger = document.getElementById('userMenuTrigger');
        const dropdown = document.getElementById('userMenuDropdown');

        if (!trigger || !dropdown) {
            console.warn('Elementos del menu no encontrados');
            return;
        }

        trigger.addEventListener('click', (e) => {
            e.stopPropagation();
            dropdown.classList.toggle('active');
        });

        document.addEventListener('click', (e) => {
            if (!trigger.contains(e.target) && !dropdown.contains(e.target)) {
                dropdown.classList.remove('active');
            }
        });

        console.log('User menu dropdown configurado');
    } catch (error) {
        console.error('Error configurando user menu dropdown:', error);
    }
}

// Change password
async function changePassword(e) {
    e.preventDefault();

    try {
        const currentPasswordEl = document.getElementById('currentPassword');
        const newPasswordEl = document.getElementById('newPassword');
        const confirmPasswordEl = document.getElementById('confirmPassword');

        if (!currentPasswordEl || !newPasswordEl || !confirmPasswordEl) {
            alert('Error: Los campos del formulario no existen');
            return;
        }

        const newPassword = newPasswordEl.value;
        const confirmPassword = confirmPasswordEl.value;

        if (newPassword !== confirmPassword) {
            alert('Las contraseñas no coinciden');
            return;
        }

        if (newPassword.length < 6) {
            alert('La contraseña debe tener al menos 6 caracteres');
            return;
        }

        const { error } = await supabase.auth.updateUser({
            password: newPassword
        });

        if (error) throw error;

        alert('Contraseña actualizada exitosamente');
        const modal = document.getElementById('changePasswordModal');
        if (modal) {
            modal.classList.remove('active');
        }
        const form = document.getElementById('changePasswordForm');
        if (form) {
            form.reset();
        }
    } catch (error) {
        console.error('Error changing password:', error);
        alert('Error al cambiar contraseña: ' + error.message);
    }
}

// Logout
async function logout() {
    try {
        const { error } = await supabase.auth.signOut();
        if (error) throw error;
        
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 500);
    } catch (error) {
        console.error('Error logging out:', error);
        // Aún así redirigir aunque falle
        window.location.href = 'index.html';
    }
}

// Initialize on load
document.addEventListener('DOMContentLoaded', initProfile);
