async function requireAdminSession() {
    const sessionResult = await supabase.auth.getSession();
    const user = sessionResult.data?.session?.user;
    if (!user) {
        window.location.href = '../login.html';
        return null;
    }

    // Verificar que el usuario tenga rol admin antes de dejarlo entrar al panel
    const { data: perfil, error } = await supabase
        .from('usuarios')
        .select('role')
        .eq('id', user.id)
        .single();

    if (error || perfil?.role !== 'admin') {
        alert('No tienes permisos de administrador para acceder a este panel.');
        window.location.href = '../index.html';
        return null;
    }

    return user;
}

async function loadAdminNav() {
    const user = await requireAdminSession();
    const nav = document.getElementById('admin-nav-links');
    if (!nav) return;
    if (user) {
        const currentPage = window.location.pathname.split('/').pop() || 'dashboard.html';
        const links = [
            { href: 'dashboard.html', icon: 'fa-chart-line', label: 'Dashboard' },
            { href: 'productos.html', icon: 'fa-gem', label: 'Productos' },
            { href: 'pedidos.html', icon: 'fa-shopping-bag', label: 'Pedidos' }
        ];
        const navLinks = links.map(link => `
            <a href="${link.href}" class="${link.href === currentPage ? 'active' : ''}">
                <i class="fas ${link.icon}"></i><span>${link.label}</span>
            </a>
        `).join('');
        nav.innerHTML = `
            ${navLinks}
            <div class="nav-divider"></div>
            <a href="../index.html"><i class="fas fa-store"></i><span>Ver tienda</span></a>
            <button class="btn-logout-link" onclick="logoutAdmin()">
                <i class="fas fa-right-from-bracket"></i><span>Cerrar sesión</span>
            </button>
        `;
    } else {
        nav.innerHTML = `
            <a href="../login.html"><i class="fas fa-right-to-bracket"></i><span>Iniciar sesión</span></a>
        `;
    }
}

async function logoutAdmin() {
    await supabase.auth.signOut();
    window.location.href = '../login.html';
}

async function loadAdminMetrics() {
    const counts = await Promise.all([
        supabase.from('productos').select('*', { count: 'exact', head: true }),
        supabase.from('pedidos').select('*', { count: 'exact', head: true }),
        supabase.from('usuarios').select('*', { count: 'exact', head: true }),
        supabase.from('cotizaciones').select('*', { count: 'exact', head: true })
    ]);

    const metricIds = ['metric-products', 'metric-orders', 'metric-users', 'metric-quotes'];
    counts.forEach((result, index) => {
        const el = document.getElementById(metricIds[index]);
        if (el && !result.error) {
            el.textContent = result.count || '0';
        }
    });
}

async function toggleProductField(id, field, value) {
    const { error } = await supabase.from('productos').update({ [field]: value }).eq('id', id);
    if (error) {
        alert('No se pudo actualizar el producto: ' + error.message);
        return;
    }
    await renderAdminProducts();
}

async function renderAdminProducts() {
    const { data, error } = await supabase.from('productos').select('id,nombre,precio,activo,destacado').order('id', { ascending: false });
    const container = document.getElementById('admin-product-list');
    if (!container) return;
    if (error) {
        container.innerHTML = `<tr><td colspan="5"><div class="admin-empty-state"><i class="fas fa-triangle-exclamation"></i>No se pudieron cargar los productos.</div></td></tr>`;
        return;
    }
    if (!data.length) {
        container.innerHTML = `<tr><td colspan="5"><div class="admin-empty-state"><i class="fas fa-gem"></i>Todavía no cargaste ningún producto.</div></td></tr>`;
        return;
    }
    container.innerHTML = data.map(product => `
        <tr>
            <td>${product.id}</td>
            <td>${product.nombre}</td>
            <td>$${Number(product.precio).toFixed(2)}</td>
            <td>
                <span class="status-badge ${product.activo ? 'status-aprobado' : 'status-rechazado'}">${product.activo ? 'Activo' : 'Inactivo'}</span>
                <button class="btn-small" onclick="toggleProductField(${product.id}, 'activo', ${!product.activo})">
                    ${product.activo ? 'Desactivar' : 'Activar'}
                </button>
            </td>
            <td>
                <span class="status-badge ${product.destacado ? 'status-aprobado' : 'status-pendiente'}">${product.destacado ? 'Destacado' : 'Normal'}</span>
                <button class="btn-small" onclick="toggleProductField(${product.id}, 'destacado', ${!product.destacado})">
                    ${product.destacado ? 'Quitar' : 'Destacar'}
                </button>
            </td>
        </tr>
    `).join('');
}

const ESTADO_LABELS = {
    pendiente: 'Pendiente',
    aprobado: 'Aprobado',
    rechazado: 'Rechazado',
    en_transito: 'En tránsito',
    entregado: 'Entregado',
    cancelado: 'Cancelado',
    reembolsado: 'Reembolsado'
};

let pedidosCache = [];
let currentEstadoFilter = 'todos';

// Estado LOGÍSTICO del pedido: pendiente | en_transito | entregado | cancelado
async function updatePedidoEstado(id, estado) {
    const confirmMsg = `¿Confirmas que quieres marcar este pedido como "${ESTADO_LABELS[estado] || estado}"?`;
    if (!confirm(confirmMsg)) return;

    const { error } = await supabase.from('pedidos').update({ estado }).eq('id', id);
    if (error) {
        alert('No se pudo actualizar el pedido: ' + error.message);
        return;
    }
    await renderAdminPedidos();
}

// Estado del PAGO: pendiente | aprobado | rechazado
async function updatePagoEstado(pedidoId, estado) {
    const confirmMsg = estado === 'aprobado'
        ? '¿Confirmas que quieres APROBAR el pago de esta venta?'
        : '¿Confirmas que quieres RECHAZAR el pago de esta venta?';
    if (!confirm(confirmMsg)) return;

    const { error } = await supabase.from('pagos').update({ estado }).eq('pedido_id', pedidoId);
    if (error) {
        alert('No se pudo actualizar el pago: ' + error.message);
        return;
    }
    await renderAdminPedidos();
    showOrderDetail(pedidoId);
}

// Reembolsa el pago en Mercado Pago (sin stock o cancelación del cliente)
// y marca el pedido como cancelado. La llamada real a Mercado Pago
// ocurre en el servidor (Edge Function), nunca acá en el navegador.
async function refundPago(pedidoId) {
    const motivo = prompt('Motivo del reembolso (ej: sin stock, cliente canceló):');
    if (motivo === null) return; // canceló el prompt

    if (!confirm('¿Confirmas que quieres REEMBOLSAR este pago al cliente? Esta acción no se puede deshacer.')) return;

    const { data, error } = await supabase.functions.invoke('refund-payment', {
        body: { pedido_id: pedidoId, motivo }
    });

    // Cuando la función responde con un status distinto a 2xx, supabase-js
    // solo pone un mensaje genérico en `error.message`. El detalle real
    // (el JSON que devolvimos con `error: "..."`) hay que sacarlo de
    // `error.context`, que es la Response original.
    let mensajeError = data?.error;
    if (error && !mensajeError) {
        mensajeError = error.message;
        try {
            const body = await error.context.json();
            if (body?.error) mensajeError = body.error;
        } catch (_) {
            // si no se pudo parsear, nos quedamos con error.message
        }
    }

    if (mensajeError) {
        alert('No se pudo reembolsar: ' + mensajeError);
        return;
    }

    alert('Reembolso realizado con éxito.');
    await renderAdminPedidos();
    showOrderDetail(pedidoId);
}

function filterPedidos(estado) {
    currentEstadoFilter = estado;
    renderAdminPedidos();
}

async function renderAdminPedidos() {
    const container = document.getElementById('admin-order-list');
    if (!container) return;

    let query = supabase
        .from('pedidos')
        .select(`
            id, total, estado, metodo_envio, direccion_envio,
            comprador_nombre, comprador_apellido, comprador_dni, comprador_email,
            creado_en,
            usuario:usuarios(email, phone, full_name),
            pedido_items(cantidad, precio_unitario, producto:productos(nombre)),
            pagos(estado, metodo, monto)
        `)
        .order('creado_en', { ascending: false })
        .limit(50);

    if (currentEstadoFilter !== 'todos') {
        query = query.eq('estado', currentEstadoFilter);
    }

    const { data, error } = await query;
    if (error) {
        console.error('Error cargando pedidos:', error);
        container.innerHTML = `<tr><td colspan="9"><div class="admin-empty-state"><i class="fas fa-triangle-exclamation"></i>No se pudieron cargar los pedidos: ${error.message}</div></td></tr>`;
        return;
    }

    pedidosCache = data || [];

    if (!pedidosCache.length) {
        container.innerHTML = `<tr><td colspan="9"><div class="admin-empty-state"><i class="fas fa-shopping-bag"></i>No hay pedidos para este filtro.</div></td></tr>`;
        return;
    }

    container.innerHTML = pedidosCache.map(order => {
        const cliente = [order.comprador_nombre, order.comprador_apellido].filter(Boolean).join(' ')
            || order.usuario?.full_name || order.usuario?.email || '---';
        const estadoLabel = ESTADO_LABELS[order.estado] || order.estado;
        const productos = (order.pedido_items || [])
            .map(it => `${it.producto?.nombre || 'Producto'} x${it.cantidad}`)
            .join(', ') || '—';
        const pago = order.pagos && order.pagos[0];
        const pagoLabel = pago ? (ESTADO_LABELS[pago.estado] || pago.estado) : '—';

        // Acciones sobre el PAGO (aprobar/rechazar) mientras esté pendiente
        const accionesPago = (pago?.estado === 'pendiente')
            ? `
                <button class="btn-small btn-approve" onclick="updatePagoEstado(${order.id}, 'aprobado')">Aprobar pago</button>
                <button class="btn-small btn-reject" onclick="updatePagoEstado(${order.id}, 'rechazado')">Rechazar pago</button>
              `
            : '';

        // Acciones sobre el PEDIDO (logística) una vez que el pago está aprobado
        const accionesPedido = (pago?.estado === 'aprobado' && order.estado === 'pendiente')
            ? `<button class="btn-small" onclick="updatePedidoEstado(${order.id}, 'en_transito')">Marcar en tránsito</button>`
            : (order.estado === 'en_transito')
                ? `<button class="btn-small" onclick="updatePedidoEstado(${order.id}, 'entregado')">Marcar entregado</button>`
                : '';

        // Reembolsar: solo si el pago está aprobado, el pedido no fue entregado
        // y todavía no se reembolsó
        const accionesReembolso = (pago?.estado === 'aprobado' && order.estado !== 'entregado')
            ? `<button class="btn-small btn-reject" onclick="refundPago(${order.id})">Reembolsar</button>`
            : '';

        const acciones = accionesPago + accionesPedido + accionesReembolso;
        return `
            <tr>
                <td>${order.id}</td>
                <td>${cliente}</td>
                <td>${productos}</td>
                <td>$${Number(order.total).toFixed(2)}</td>
                <td>${order.metodo_envio || 'Sin definir'}</td>
                <td><span class="status-badge status-${order.estado}">${estadoLabel}</span></td>
                <td><span class="status-badge status-${pago?.estado || 'pendiente'}">${pagoLabel}</span></td>
                <td>${new Date(order.creado_en).toLocaleString('es-AR')}</td>
                <td class="admin-order-actions">
                    <button class="btn-small" onclick="showOrderDetail(${order.id})">Ver detalle</button>
                    ${acciones}
                </td>
            </tr>
        `;
    }).join('');
}

function showOrderDetail(id) {
    const order = pedidosCache.find(o => o.id === id);
    const modal = document.getElementById('order-detail-modal');
    const body = document.getElementById('order-detail-body');
    if (!order || !modal || !body) return;

    const cliente = [order.comprador_nombre, order.comprador_apellido].filter(Boolean).join(' ')
        || order.usuario?.full_name || '---';
    const pago = order.pagos && order.pagos[0];

    const productosHtml = (order.pedido_items || []).map(it => `
        <tr>
            <td>${it.producto?.nombre || 'Producto'}</td>
            <td>${it.cantidad}</td>
            <td>$${Number(it.precio_unitario).toFixed(2)}</td>
            <td>$${(Number(it.precio_unitario) * Number(it.cantidad)).toFixed(2)}</td>
        </tr>
    `).join('') || '<tr><td colspan="4">Sin productos registrados</td></tr>';

    const pagoAcciones = pago && pago.estado === 'pendiente'
        ? `
            <button class="btn-small btn-approve" onclick="updatePagoEstado(${order.id}, 'aprobado')">Marcar pago aprobado</button>
            <button class="btn-small btn-reject" onclick="updatePagoEstado(${order.id}, 'rechazado')">Marcar pago rechazado</button>
          `
        : (pago && pago.estado === 'aprobado' && order.estado !== 'entregado')
            ? `<button class="btn-small btn-reject" onclick="refundPago(${order.id})">Reembolsar pago</button>`
            : '';

    body.innerHTML = `
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.6rem 1.5rem; margin-bottom:1rem;">
            <p><strong>Cliente:</strong> ${cliente}</p>
            <p><strong>Email:</strong> ${order.comprador_email || order.usuario?.email || '---'}</p>
            <p><strong>DNI:</strong> ${order.comprador_dni || '---'}</p>
            <p><strong>Celular:</strong> ${order.usuario?.phone || '---'}</p>
            <p style="grid-column:1 / -1;"><strong>Dirección:</strong> ${order.direccion_envio || '---'}</p>
            <p><strong>Método de pago:</strong> ${order.metodo_envio || '---'}</p>
            <p><strong>Estado del pago:</strong> <span class="status-badge status-${pago?.estado || 'pendiente'}">${pago ? (ESTADO_LABELS[pago.estado] || pago.estado) : '---'}</span></p>
            <p><strong>Estado del pedido:</strong> <span class="status-badge status-${order.estado}">${ESTADO_LABELS[order.estado] || order.estado}</span></p>
            <p><strong>Fecha:</strong> ${new Date(order.creado_en).toLocaleString('es-AR')}</p>
        </div>

        <table style="width:100%; border-collapse:collapse;">
            <thead>
                <tr style="text-align:left; border-bottom:1px solid var(--border);">
                    <th style="padding:0.5rem 0;">Producto</th>
                    <th>Cant.</th>
                    <th>P. Unitario</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>${productosHtml}</tbody>
        </table>
        <p style="text-align:right; margin-top:1rem; font-weight:700;">Total: $${Number(order.total).toFixed(2)}</p>

        <div style="margin-top:1rem; display:flex; gap:0.5rem; flex-wrap:wrap;">${pagoAcciones}</div>
    `;
    modal.classList.add('active');
}

function closeOrderDetail() {
    const modal = document.getElementById('order-detail-modal');
    if (modal) modal.classList.remove('active');
}

window.addEventListener('DOMContentLoaded', () => {
    loadAdminNav();
    if (document.getElementById('metric-products')) {
        loadAdminMetrics();
    }
    if (document.getElementById('admin-product-list')) {
        renderAdminProducts();
    }
    if (document.getElementById('admin-order-list')) {
        renderAdminPedidos();
    }
});
