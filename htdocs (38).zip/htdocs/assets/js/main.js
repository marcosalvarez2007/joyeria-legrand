window.mainJsLoaded = false;
window.mainJsLoadError = null;
try {
    window.mainJsLoaded = true;
} catch (e) {
    window.mainJsLoadError = e.message;
}

var productCache = new Map();
var MAIN_DEFAULT_IMAGE = 'https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?auto=format&fit=crop&w=900&q=80';

function normalizeImageSrc(src, category) {
    const image = String(src || '').trim();
    if (!image || image.includes('picsum.photos') || image.includes('placeholder.com') || image.includes('plant') || image.includes('tree') || image.includes('leaf')) {
        return getDefaultImageForCategory(category);
    }
    return image;
}

function normalizeProduct(product) {
    if (!product || typeof product !== 'object') return null;
    const imagenes = Array.isArray(product.imagenes) && product.imagenes.length ? product.imagenes : [MAIN_DEFAULT_IMAGE];
    return {
        ...product,
        id: Number(product.id),
        cantidad: Number(product.cantidad) || 1,
        imagenes: imagenes.map(src => normalizeImageSrc(src, product?.categoria?.nombre))
    };
}

function normalizeCartItems(items) {
    if (!Array.isArray(items)) return [];
    return items.map(normalizeProduct).filter(Boolean);
}

var carrito = [];

const CATEGORY_KEYS = ['Todos', 'Anillos', 'Collares', 'Aretes', 'Pulseras', 'Relojes'];
let catalogProducts = [];
let catalogCategoryFilter = 'Todos';
let catalogSearchTerm = '';

var sampleProducts = (typeof JEWELRY_CATALOG !== "undefined") ? JEWELRY_CATALOG : [
    {
        id: 1,
        nombre: 'Anillo Solitario Clasico',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Solitario Clasico.',
        precio: 965,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-solitario-clasico',
        imagenes: ['https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?auto=format&fit=crop&w=900&q=80'],
        activo: true,
        destacado: false
    },
    {
        id: 2,
        nombre: 'Anillo Compromiso Diamante',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Compromiso Diamante.',
        precio: 980,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-compromiso-diamante',
        imagenes: ['https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=900&q=80'],
        activo: true,
        destacado: false
    },
    {
        id: 3,
        nombre: 'Anillo Alianza Corrugada',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Alianza Corrugada.',
        precio: 995,
        categoria: { nombre: 'Anillos' },
         url:' images.jfif',
        imagenes: ['images.jfif'],
        activo: true,
        destacado: false
    },
    {
        id: 4,
        nombre: 'Anillo Plata Esterlina Onda',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Plata Esterlina Onda.',
        precio: 1010,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-plata-esterlina-onda',
        imagenes: ['https://images.unsplash.com/photo-1594652417406-1ecb887ee25d?auto=format&fit=crop&w=900&q=80'],
        activo: true,
        destacado: false
    },
    {
        id: 5,
        nombre: 'Anillo Oro Rosa Corazon',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Oro Rosa Corazon.',
        precio: 1025,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-oro-rosa-corazon',
        imagenes: ['https://images.unsplash.com/photo-1508051123996-69f8caf4891f?auto=format&fit=crop&w=900&q=80'],
        activo: true,
        destacado: false
    },
    {
        id: 6,
        nombre: 'Anillo Ajustable Hojas',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Ajustable Hojas.',
        precio: 1040,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-ajustable-hojas',
        imagenes: ['https://images.unsplash.com/photo-1511450282262-9e4e9d8db1d2?auto=format&fit=crop&w=900&q=80'],
        activo: true,
        destacado: false
    },
    {
        id: 7,
        nombre: 'Anillo Sello Piedra Negra',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Sello Piedra Negra.',
        precio: 1055,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-sello-piedra-negra',
        imagenes: ['https://images.unsplash.com/photo-15009182428-22da5e4ffc15?auto=format&fit=crop&w=900&q=80'],
        activo: true,
        destacado: true
    },
    {
        id: 8,
        nombre: 'Anillo Corona Princesa',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Corona Princesa.',
        precio: 1070,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-corona-princesa',
        imagenes: ['https://images.unsplash.com/photo-1520410389130-c38ddbbd73b1?auto=format&fit=crop&w=900&q=80'],
        activo: true,
        destacado: false
    },
    {
        id: 9,
        nombre: 'Anillo Infinito Minimalista',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Infinito Minimalista.',
        precio: 1085,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-infinito-minimalista',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Anillo+Infinito+Minimalista'],
        activo: true,
        destacado: false
    },
    {
        id: 10,
        nombre: 'Anillo Cruzado Circones',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Cruzado Circones.',
        precio: 1100,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-cruzado-circones',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Anillo+Cruzado+Circones'],
        activo: true,
        destacado: false
    },
    {
        id: 11,
        nombre: 'Anillo Amatista Natural',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Amatista Natural.',
        precio: 1115,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-amatista-natural',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Anillo+Amatista+Natural'],
        activo: true,
        destacado: false
    },
    {
        id: 12,
        nombre: 'Anillo Esmeralda Cuadrada',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Esmeralda Cuadrada.',
        precio: 1130,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-esmeralda-cuadrada',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Anillo+Esmeralda+Cuadrada'],
        activo: true,
        destacado: false
    },
    {
        id: 13,
        nombre: 'Anillo Triple Trenzado',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Triple Trenzado.',
        precio: 1145,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-triple-trenzado',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Anillo+Triple+Trenzado'],
        activo: true,
        destacado: false
    },
    {
        id: 14,
        nombre: 'Anillo Sello Grabado',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Sello Grabado.',
        precio: 1160,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-sello-grabado',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Anillo+Sello+Grabado'],
        activo: true,
        destacado: true
    },
    {
        id: 15,
        nombre: 'Anillo Geometrico Hexagonal',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Geometrico Hexagonal.',
        precio: 1175,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-geometrico-hexagonal',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Anillo+Geometrico+Hexagonal'],
        activo: true,
        destacado: false
    },
    {
        id: 16,
        nombre: 'Anillo Midi Falange',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Midi Falange.',
        precio: 1190,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-midi-falange',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Anillo+Midi+Falange'],
        activo: true,
        destacado: false
    },
    {
        id: 17,
        nombre: 'Anillo Perla Cultivada',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Perla Cultivada.',
        precio: 1205,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-perla-cultivada',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Anillo+Perla+Cultivada'],
        activo: true,
        destacado: false
    },
    {
        id: 18,
        nombre: 'Anillo Acero Quirurgico Negro',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Acero Quirurgico Negro.',
        precio: 1220,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-acero-quirurgico-negro',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Anillo+Acero+Quirurgico+Negro'],
        activo: true,
        destacado: false
    },
    {
        id: 19,
        nombre: 'Anillo Ojo Turco Protector',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Ojo Turco Protector.',
        precio: 1235,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-ojo-turco-protector',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Anillo+Ojo+Turco+Protector'],
        activo: true,
        destacado: false
    },
    {
        id: 20,
        nombre: 'Anillo Vintage Opalo',
        descripcion: 'Descripcion elegante y exclusiva para Anillo Vintage Opalo.',
        precio: 1250,
        categoria: { nombre: 'Anillos' },
        url: 'https://example.com/producto/anillo-vintage-opalo',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Anillo+Vintage+Opalo'],
        activo: true,
        destacado: false
    },
    {
        id: 21,
        nombre: 'Gargantilla Oro Fina',
        descripcion: 'Descripcion elegante y exclusiva para Gargantilla Oro Fina.',
        precio: 1265,
        categoria: { nombre: 'Collares' },
        url: 'https://example.com/producto/gargantilla-oro-fina',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Gargantilla+Oro+Fina'],
        activo: true,
        destacado: true
    },
    {
        id: 22,
        nombre: 'Collar Dije Luna',
        descripcion: 'Descripcion elegante y exclusiva para Collar Dije Luna.',
        precio: 1280,
        categoria: { nombre: 'Collares' },
        url: 'https://example.com/producto/collar-dije-luna',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Collar+Dije+Luna'],
        activo: true,
        destacado: false
    },
    {
        id: 23,
        nombre: 'Collar Perlas Barrocas',
        descripcion: 'Descripcion elegante y exclusiva para Collar Perlas Barrocas.',
        precio: 1295,
        categoria: { nombre: 'Collares' },
        url: 'https://example.com/producto/collar-perlas-barrocas',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Collar+Perlas+Barrocas'],
        activo: true,
        destacado: false
    },
    {
        id: 24,
        nombre: 'Collar Inicial Personalizada',
        descripcion: 'Descripcion elegante y exclusiva para Collar Inicial Personalizada.',
        precio: 1310,
        categoria: { nombre: 'Collares' },
        url: 'https://example.com/producto/collar-inicial-personalizada',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Collar+Inicial+Personalizada'],
        activo: true,
        destacado: false
    },
    {
        id: 25,
        nombre: 'Cadena Eslabon Cubano',
        descripcion: 'Descripcion elegante y exclusiva para Cadena Eslabon Cubano.',
        precio: 1325,
        categoria: { nombre: 'Collares' },
        url: 'https://example.com/producto/cadena-eslabon-cubano',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Cadena+Eslabon+Cubano'],
        activo: true,
        destacado: false
    },
    {
        id: 26,
        nombre: 'Collar Medalla Sol',
        descripcion: 'Descripcion elegante y exclusiva para Collar Medalla Sol.',
        precio: 1340,
        categoria: { nombre: 'Collares' },
        url: 'https://example.com/producto/collar-medalla-sol',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Collar+Medalla+Sol'],
        activo: true,
        destacado: false
    },
    {
        id: 27,
        nombre: 'Collar Plata Cuarzo Rosa',
        descripcion: 'Descripcion elegante y exclusiva para Collar Plata Cuarzo Rosa.',
        precio: 1355,
        categoria: { nombre: 'Collares' },
        url: 'https://example.com/producto/collar-plata-cuarzo-rosa',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Collar+Plata+Cuarzo+Rosa'],
        activo: true,
        destacado: false
    },
    {
        id: 28,
        nombre: 'Choker Cristal',
        descripcion: 'Descripcion elegante y exclusiva para Choker Cristal.',
        precio: 1370,
        categoria: { nombre: 'Collares' },
        url: 'https://example.com/producto/choker-cristal',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Choker+Cristal'],
        activo: true,
        destacado: true
    },
    {
        id: 29,
        nombre: 'Collar Capas Multiples',
        descripcion: 'Descripcion elegante y exclusiva para Collar Capas Multiples.',
        precio: 1385,
        categoria: { nombre: 'Collares' },
        url: 'https://example.com/producto/collar-capas-multiples',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Collar+Capas+Multiples'],
        activo: true,
        destacado: false
    },
    {
        id: 30,
        nombre: 'Collar Arbol Vida',
        descripcion: 'Descripcion elegante y exclusiva para Collar Arbol Vida.',
        precio: 1400,
        categoria: { nombre: 'Collares' },
        url: 'https://example.com/producto/collar-arbol-vida',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Collar+Arbol+Vida'],
        activo: true,
        destacado: false
    },
    {
        id: 31,
        nombre: 'Collar Hilo Invisible Luz',
        descripcion: 'Descripcion elegante y exclusiva para Collar Hilo Invisible Luz.',
        precio: 1415,
        categoria: { nombre: 'Collares' },
        url: 'https://example.com/producto/collar-hilo-invisible-luz',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Collar+Hilo+Invisible+Luz'],
        activo: true,
        destacado: false
    },
    {
        id: 32,
        nombre: 'Collar Turquesa',
        descripcion: 'Descripcion elegante y exclusiva para Collar Turquesa.',
        precio: 1430,
        categoria: { nombre: 'Collares' },
        url: 'https://example.com/producto/collar-turquesa',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Collar+Turquesa'],
        activo: true,
        destacado: false
    },
    {
        id: 33,
        nombre: 'Cadena Plata Veneciana',
        descripcion: 'Descripcion elegante y exclusiva para Cadena Plata Veneciana.',
        precio: 1445,
        categoria: { nombre: 'Collares' },
        url: 'https://example.com/producto/cadena-plata-veneciana',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Cadena+Plata+Veneciana'],
        activo: true,
        destacado: false
    },
    {
        id: 34,
        nombre: 'Collar Amuleto Llave',
        descripcion: 'Descripcion elegante y exclusiva para Collar Amuleto Llave.',
        precio: 1460,
        categoria: { nombre: 'Collares' },
        url: 'https://example.com/producto/collar-amuleto-llave',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Collar+Amuleto+Llave'],
        activo: true,
        destacado: false
    },
    {
        id: 35,
        nombre: 'Collar Barra Horizontal',
        descripcion: 'Descripcion elegante y exclusiva para Collar Barra Horizontal.',
        precio: 1475,
        categoria: { nombre: 'Collares' },
        url: 'https://example.com/producto/collar-barra-horizontal',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Collar+Barra+Horizontal'],
        activo: true,
        destacado: true
    },
    {
        id: 36,
        nombre: 'Argollas Oro Medianas',
        descripcion: 'Descripcion elegante y exclusiva para Argollas Oro Medianas.',
        precio: 1490,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/argollas-oro-medianas',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Argollas+Oro+Medianas'],
        activo: true,
        destacado: false
    },
    {
        id: 37,
        nombre: 'Broqueles Diamante Basico',
        descripcion: 'Descripcion elegante y exclusiva para Broqueles Diamante Basico.',
        precio: 1505,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/broqueles-diamante-basico',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Broqueles+Diamante+Basico'],
        activo: true,
        destacado: false
    },
    {
        id: 38,
        nombre: 'Aretes Colgantes Filigrana',
        descripcion: 'Descripcion elegante y exclusiva para Aretes Colgantes Filigrana.',
        precio: 1520,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/aretes-colgantes-filigrana',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Aretes+Colgantes+Filigrana'],
        activo: true,
        destacado: false
    },
    {
        id: 39,
        nombre: 'Ear Cuff Plata Ajustable',
        descripcion: 'Descripcion elegante y exclusiva para Ear Cuff Plata Ajustable.',
        precio: 1535,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/ear-cuff-plata-ajustable',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Ear+Cuff+Plata+Ajustable'],
        activo: true,
        destacado: false
    },
    {
        id: 40,
        nombre: 'Aretes Aro Piedra',
        descripcion: 'Descripcion elegante y exclusiva para Aretes Aro Piedra.',
        precio: 1550,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/aretes-aro-piedra',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Aretes+Aro+Piedra'],
        activo: true,
        destacado: false
    },
    {
        id: 41,
        nombre: 'Broqueles Perla Blanca',
        descripcion: 'Descripcion elegante y exclusiva para Broqueles Perla Blanca.',
        precio: 1565,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/broqueles-perla-blanca',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Broqueles+Perla+Blanca'],
        activo: true,
        destacado: false
    },
    {
        id: 42,
        nombre: 'Aretes Largos Cadena',
        descripcion: 'Descripcion elegante y exclusiva para Aretes Largos Cadena.',
        precio: 1580,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/aretes-largos-cadena',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Aretes+Largos+Cadena'],
        activo: true,
        destacado: true
    },
    {
        id: 43,
        nombre: 'Aretes Estrella Luna',
        descripcion: 'Descripcion elegante y exclusiva para Aretes Estrella Luna.',
        precio: 1595,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/aretes-estrella-luna',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Aretes+Estrella+Luna'],
        activo: true,
        destacado: false
    },
    {
        id: 44,
        nombre: 'Aretes Boton Geometricos',
        descripcion: 'Descripcion elegante y exclusiva para Aretes Boton Geometricos.',
        precio: 1610,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/aretes-boton-geometricos',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Aretes+Boton+Geometricos'],
        activo: true,
        destacado: false
    },
    {
        id: 45,
        nombre: 'Climbers Hojas Plata',
        descripcion: 'Descripcion elegante y exclusiva para Climbers Hojas Plata.',
        precio: 1625,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/climbers-hojas-plata',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Climbers+Hojas+Plata'],
        activo: true,
        destacado: false
    },
    {
        id: 46,
        nombre: 'Aretes Aro Gruesos Chunky',
        descripcion: 'Descripcion elegante y exclusiva para Aretes Aro Gruesos Chunky.',
        precio: 1640,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/aretes-aro-gruesos-chunky',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Aretes+Aro+Gruesos+Chunky'],
        activo: true,
        destacado: false
    },
    {
        id: 47,
        nombre: 'Aretes Flecos Oro',
        descripcion: 'Descripcion elegante y exclusiva para Aretes Flecos Oro.',
        precio: 1655,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/aretes-flecos-oro',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Aretes+Flecos+Oro'],
        activo: true,
        destacado: false
    },
    {
        id: 48,
        nombre: 'Broqueles Corazon Minimalista',
        descripcion: 'Descripcion elegante y exclusiva para Broqueles Corazon Minimalista.',
        precio: 1670,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/broqueles-corazon-minimalista',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Broqueles+Corazon+Minimalista'],
        activo: true,
        destacado: false
    },
    {
        id: 49,
        nombre: 'Aretes Zafiro Azul Cuadrados',
        descripcion: 'Descripcion elegante y exclusiva para Aretes Zafiro Azul Cuadrados.',
        precio: 1685,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/aretes-zafiro-azul-cuadrados',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Aretes+Zafiro+Azul+Cuadrados'],
        activo: true,
        destacado: true
    },
    {
        id: 50,
        nombre: 'Aretes Colgantes Resina Carey',
        descripcion: 'Descripcion elegante y exclusiva para Aretes Colgantes Resina Carey.',
        precio: 1700,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/aretes-colgantes-resina-carey',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Aretes+Colgantes+Resina+Carey'],
        activo: true,
        destacado: false
    },
    {
        id: 51,
        nombre: 'Aretes Cruz Colgante',
        descripcion: 'Descripcion elegante y exclusiva para Aretes Cruz Colgante.',
        precio: 1715,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/aretes-cruz-colgante',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Aretes+Cruz+Colgante'],
        activo: true,
        destacado: false
    },
    {
        id: 52,
        nombre: 'Broqueles Trebol Cuatro Hojas',
        descripcion: 'Descripcion elegante y exclusiva para Broqueles Trebol Cuatro Hojas.',
        precio: 1730,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/broqueles-trebol-cuatro-hojas',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Broqueles+Trebol+Cuatro+Hojas'],
        activo: true,
        destacado: false
    },
    {
        id: 53,
        nombre: 'Aretes Hilo Largo',
        descripcion: 'Descripcion elegante y exclusiva para Aretes Hilo Largo.',
        precio: 1745,
        categoria: { nombre: 'Aretes' },
        url: 'https://example.com/producto/aretes-hilo-largo',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Aretes+Hilo+Largo'],
        activo: true,
        destacado: false
    },
    {
        id: 54,
        nombre: 'Pulsera Cadena Eslabones',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Cadena Eslabones.',
        precio: 1760,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-cadena-eslabones',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Cadena+Eslabones'],
        activo: true,
        destacado: false
    },
    {
        id: 55,
        nombre: 'Pulsera Esclava Grabable',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Esclava Grabable.',
        precio: 1775,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-esclava-grabable',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Esclava+Grabable'],
        activo: true,
        destacado: false
    },
    {
        id: 56,
        nombre: 'Pulsera Dijes Tipo Pandora',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Dijes Tipo Pandora.',
        precio: 1790,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-dijes-tipo-pandora',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Dijes+Tipo+Pandora'],
        activo: true,
        destacado: true
    },
    {
        id: 57,
        nombre: 'Brazalete Rigido Oro',
        descripcion: 'Descripcion elegante y exclusiva para Brazalete Rigido Oro.',
        precio: 1805,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/brazalete-rigido-oro',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Brazalete+Rigido+Oro'],
        activo: true,
        destacado: false
    },
    {
        id: 58,
        nombre: 'Pulsera Tennis Circones',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Tennis Circones.',
        precio: 1820,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-tennis-circones',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Tennis+Circones'],
        activo: true,
        destacado: false
    },
    {
        id: 59,
        nombre: 'Pulsera Hilo Rojo Ojo Turco',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Hilo Rojo Ojo Turco.',
        precio: 1835,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-hilo-rojo-ojo-turco',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Hilo+Rojo+Ojo+Turco'],
        activo: true,
        destacado: false
    },
    {
        id: 60,
        nombre: 'Pulsera Piedras Volcanicas',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Piedras Volcanicas.',
        precio: 1850,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-piedras-volcanicas',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Piedras+Volcanicas'],
        activo: true,
        destacado: false
    },
    {
        id: 61,
        nombre: 'Brazalete Abierto Ajustable',
        descripcion: 'Descripcion elegante y exclusiva para Brazalete Abierto Ajustable.',
        precio: 1865,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/brazalete-abierto-ajustable',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Brazalete+Abierto+Ajustable'],
        activo: true,
        destacado: false
    },
    {
        id: 62,
        nombre: 'Pulsera Plata Infinito',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Plata Infinito.',
        precio: 1880,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-plata-infinito',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Plata+Infinito'],
        activo: true,
        destacado: false
    },
    {
        id: 63,
        nombre: 'Pulsera Macrame Tejida',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Macrame Tejida.',
        precio: 1895,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-macrame-tejida',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Macrame+Tejida'],
        activo: true,
        destacado: true
    },
    {
        id: 64,
        nombre: 'Pulsera Tobillo Cascabeles',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Tobillo Cascabeles.',
        precio: 1910,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-tobillo-cascabeles',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Tobillo+Cascabeles'],
        activo: true,
        destacado: false
    },
    {
        id: 65,
        nombre: 'Pulsera Cuero Trenzado Hombre',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Cuero Trenzado Hombre.',
        precio: 1925,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-cuero-trenzado-hombre',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Cuero+Trenzado+Hombre'],
        activo: true,
        destacado: false
    },
    {
        id: 66,
        nombre: 'Pulsera Ajustable Cordon',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Ajustable Cordon.',
        precio: 1940,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-ajustable-cordon',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Ajustable+Cordon'],
        activo: true,
        destacado: false
    },
    {
        id: 67,
        nombre: 'Pulsera Doble Cadena Oro Plata',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Doble Cadena Oro Plata.',
        precio: 1955,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-doble-cadena-oro-plata',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Doble+Cadena+Oro+Plata'],
        activo: true,
        destacado: false
    },
    {
        id: 68,
        nombre: 'Brazalete Ancho Labrado',
        descripcion: 'Descripcion elegante y exclusiva para Brazalete Ancho Labrado.',
        precio: 1970,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/brazalete-ancho-labrado',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Brazalete+Ancho+Labrado'],
        activo: true,
        destacado: false
    },
    {
        id: 69,
        nombre: 'Pulsera Agatas Naturales',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Agatas Naturales.',
        precio: 1985,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-agatas-naturales',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Agatas+Naturales'],
        activo: true,
        destacado: false
    },
    {
        id: 70,
        nombre: 'Pulsera Perlas Rio Finas',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Perlas Rio Finas.',
        precio: 2000,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-perlas-rio-finas',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Perlas+Rio+Finas'],
        activo: true,
        destacado: true
    },
    {
        id: 71,
        nombre: 'Pulsera Dije Arbol Familiar',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Dije Arbol Familiar.',
        precio: 2015,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-dije-arbol-familiar',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Dije+Arbol+Familiar'],
        activo: true,
        destacado: false
    },
    {
        id: 72,
        nombre: 'Brazalete Geometrico Minimal',
        descripcion: 'Descripcion elegante y exclusiva para Brazalete Geometrico Minimal.',
        precio: 2030,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/brazalete-geometrico-minimal',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Brazalete+Geometrico+Minimal'],
        activo: true,
        destacado: false
    },
    {
        id: 73,
        nombre: 'Pulsera Eslabon Corazon',
        descripcion: 'Descripcion elegante y exclusiva para Pulsera Eslabon Corazon.',
        precio: 2045,
        categoria: { nombre: 'Pulseras' },
        url: 'https://example.com/producto/pulsera-eslabon-corazon',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Pulsera+Eslabon+Corazon'],
        activo: true,
        destacado: false
    },
    {
        id: 74,
        nombre: 'Reloj Cronografo Deportivo Negro',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Cronografo Deportivo Negro.',
        precio: 2060,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-cronografo-deportivo-negro',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Cronografo+Deportivo+Negro'],
        activo: true,
        destacado: false
    },
    {
        id: 75,
        nombre: 'Reloj Clasico Cuero Marron',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Clasico Cuero Marron.',
        precio: 2075,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-clasico-cuero-marron',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Clasico+Cuero+Marron'],
        activo: true,
        destacado: false
    },
    {
        id: 76,
        nombre: 'Reloj Lujo Oro 18k',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Lujo Oro 18k.',
        precio: 2090,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-lujo-oro-18k',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Lujo+Oro+18k'],
        activo: true,
        destacado: false
    },
    {
        id: 77,
        nombre: 'Reloj Analogico Plata Minimalista',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Analogico Plata Minimalista.',
        precio: 2105,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-analogico-plata-minimalista',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Analogico+Plata+Minimalista'],
        activo: true,
        destacado: true
    },
    {
        id: 78,
        nombre: 'Reloj Digital Retro',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Digital Retro.',
        precio: 2120,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-digital-retro',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Digital+Retro'],
        activo: true,
        destacado: false
    },
    {
        id: 79,
        nombre: 'Reloj Automatico Esfera Abierta',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Automatico Esfera Abierta.',
        precio: 2135,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-automatico-esfera-abierta',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Automatico+Esfera+Abierta'],
        activo: true,
        destacado: false
    },
    {
        id: 80,
        nombre: 'Reloj Inteligente Smartwatch Sport',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Inteligente Smartwatch Sport.',
        precio: 2150,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-inteligente-smartwatch-sport',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Inteligente+Smartwatch+Sport'],
        activo: true,
        destacado: false
    },
    {
        id: 81,
        nombre: 'Reloj Correa Oro Rosa',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Correa Oro Rosa.',
        precio: 2165,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-correa-oro-rosa',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Correa+Oro+Rosa'],
        activo: true,
        destacado: false
    },
    {
        id: 82,
        nombre: 'Reloj Cuarzo Esfera Azul',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Cuarzo Esfera Azul.',
        precio: 2180,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-cuarzo-esfera-azul',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Cuarzo+Esfera+Azul'],
        activo: true,
        destacado: false
    },
    {
        id: 83,
        nombre: 'Reloj Buceo Resistente Agua',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Buceo Resistente Agua.',
        precio: 2195,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-buceo-resistente-agua',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Buceo+Resistente+Agua'],
        activo: true,
        destacado: false
    },
    {
        id: 84,
        nombre: 'Reloj Casual Correa Lona',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Casual Correa Lona.',
        precio: 2210,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-casual-correa-lona',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Casual+Correa+Lona'],
        activo: true,
        destacado: true
    },
    {
        id: 85,
        nombre: 'Reloj Esfera Marmol Blanco',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Esfera Marmol Blanco.',
        precio: 2225,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-esfera-marmol-blanco',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Esfera+Marmol+Blanco'],
        activo: true,
        destacado: false
    },
    {
        id: 86,
        nombre: 'Reloj Bolsillo Vintage',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Bolsillo Vintage.',
        precio: 2240,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-bolsillo-vintage',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Bolsillo+Vintage'],
        activo: true,
        destacado: false
    },
    {
        id: 87,
        nombre: 'Reloj Titanio Ultraligero',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Titanio Ultraligero.',
        precio: 2255,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-titanio-ultraligero',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Titanio+Ultraligero'],
        activo: true,
        destacado: false
    },
    {
        id: 88,
        nombre: 'Reloj Pulsera Ceramica Blanca',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Pulsera Ceramica Blanca.',
        precio: 2270,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-pulsera-ceramica-blanca',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Pulsera+Ceramica+Blanca'],
        activo: true,
        destacado: false
    },
    {
        id: 89,
        nombre: 'Reloj Esfera Negra Caja Acero',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Esfera Negra Caja Acero.',
        precio: 2285,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-esfera-negra-caja-acero',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Esfera+Negra+Caja+Acero'],
        activo: true,
        destacado: false
    },
    {
        id: 90,
        nombre: 'Reloj Minimalista Ultra Delgado',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Minimalista Ultra Delgado.',
        precio: 2300,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-minimalista-ultra-delgado',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Minimalista+Ultra+Delgado'],
        activo: true,
        destacado: false
    },
    {
        id: 91,
        nombre: 'Reloj Solar Eco Friendly',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Solar Eco Friendly.',
        precio: 2315,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-solar-eco-friendly',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Solar+Eco+Friendly'],
        activo: true,
        destacado: true
    },
    {
        id: 92,
        nombre: 'Reloj Oro Blanco Diamantes',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Oro Blanco Diamantes.',
        precio: 2330,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-oro-blanco-diamantes',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Oro+Blanco+Diamantes'],
        activo: true,
        destacado: false
    },
    {
        id: 93,
        nombre: 'Reloj Militar Multifuncion',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Militar Multifuncion.',
        precio: 2345,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-militar-multifuncion',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Militar+Multifuncion'],
        activo: true,
        destacado: false
    },
    {
        id: 94,
        nombre: 'Reloj Correa Malla Oro',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Correa Malla Oro.',
        precio: 2360,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-correa-malla-oro',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Correa+Malla+Oro'],
        activo: true,
        destacado: false
    },
    {
        id: 95,
        nombre: 'Reloj Esfera Verde Esmeralda',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Esfera Verde Esmeralda.',
        precio: 2375,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-esfera-verde-esmeralda',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Esfera+Verde+Esmeralda'],
        activo: true,
        destacado: false
    },
    {
        id: 96,
        nombre: 'Reloj Cuadrado Clasico Cuero',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Cuadrado Clasico Cuero.',
        precio: 2390,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-cuadrado-clasico-cuero',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Cuadrado+Clasico+Cuero'],
        activo: true,
        destacado: false
    },
    {
        id: 97,
        nombre: 'Reloj Esqueleto Esfera Visible',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Esqueleto Esfera Visible.',
        precio: 2405,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-esqueleto-esfera-visible',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Esqueleto+Esfera+Visible'],
        activo: true,
        destacado: false
    },
    {
        id: 98,
        nombre: 'Reloj Pulsera Joya Circones',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Pulsera Joya Circones.',
        precio: 2420,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-pulsera-joya-circones',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Pulsera+Joya+Circones'],
        activo: true,
        destacado: true
    },
    {
        id: 99,
        nombre: 'Reloj Inteligente Hibrido Elegante',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Inteligente Hibrido Elegante.',
        precio: 2435,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-inteligente-hibrido-elegante',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Inteligente+Hibrido+Elegante'],
        activo: true,
        destacado: false
    },
    {
        id: 100,
        nombre: 'Reloj Edicion Limitada Coleccion',
        descripcion: 'Descripcion elegante y exclusiva para Reloj Edicion Limitada Coleccion.',
        precio: 2450,
        categoria: { nombre: 'Relojes' },
        url: 'https://example.com/producto/reloj-edicion-limitada-coleccion',
        imagenes: ['https://via.placeholder.com/900x900.png?text=Reloj+Edicion+Limitada+Coleccion'],
        activo: true,
        destacado: false
    }
];

function getDefaultImageForCategory(category) {
    const key = String(category || '').toLowerCase();
    const map = {
        anillos: 'https://images.pexels.com/photos/962989/pexels-photo-962989.jpeg?auto=compress&cs=tinysrgb&w=900',
        collares: 'https://images.pexels.com/photos/1452967/pexels-photo-1452967.jpeg?auto=compress&cs=tinysrgb&w=900',
        aretes: 'https://images.pexels.com/photos/1436948/pexels-photo-1436948.jpeg?auto=compress&cs=tinysrgb&w=900',
        pulseras: 'https://images.pexels.com/photos/347149/pexels-photo-347149.jpeg?auto=compress&cs=tinysrgb&w=900',
        relojes: 'https://images.pexels.com/photos/171953/pexels-photo-171953.jpeg?auto=compress&cs=tinysrgb&w=900'
    };
    return map[key] || MAIN_DEFAULT_IMAGE;
}

function getProductImage(product) {
    const firstImage = Array.isArray(product.imagenes) && product.imagenes.length ? product.imagenes[0] : '';
    return normalizeImageSrc(firstImage, product.categoria?.nombre);
}

function normalizeCategory(value) {
    if (!value) return 'Todos';
    const search = String(value).trim().toLowerCase();
    const match = CATEGORY_KEYS.find(cat => cat.toLowerCase() === search);
    return match || 'Todos';
}

function getCatalogFilterFromLocation() {
    const params = new URLSearchParams(window.location.search);
    const queryCategory = params.get('categoria');
    const hashCategory = window.location.hash?.replace('#', '');
    return normalizeCategory(hashCategory || queryCategory);
}

function updateCatalogHeading(category) {
    const title = document.getElementById('catalog-title');
    const subtitle = document.getElementById('catalog-subtitle');
    if (!title || !subtitle) return;
    title.textContent = category === 'Todos' ? 'Colección de joyas Legrand' : `Sección de ${category}`;
    subtitle.textContent = category === 'Todos'
        ? 'Explora piezas exclusivas con materiales nobles, diseños atemporales y detalles de alta joyería. Haz clic en cada producto para conocer sus características y contactarnos en WhatsApp.'
        : `Mostrando solo ${category.toLowerCase()} de nuestra colección premium. Encuentra tu pieza ideal con estilo y elegancia.`;
}

function renderCategoryFilters(activeCategory) {
    const container = document.getElementById('category-filters');
    if (!container) return;
    container.innerHTML = CATEGORY_KEYS.map(category => `
        <button type="button" class="category-chip${category === activeCategory ? ' active' : ''}" data-category="${category}">${category}</button>
    `).join('');
    container.querySelectorAll('.category-chip').forEach(button => {
        button.addEventListener('click', () => setCategoryFilter(button.dataset.category));
    });
}

function setCategoryFilter(category) {
    catalogCategoryFilter = normalizeCategory(category);
    if (catalogCategoryFilter === 'Todos') {
        history.replaceState(null, '', 'catalogo.html');
    } else {
        history.replaceState(null, '', `catalogo.html?categoria=${encodeURIComponent(catalogCategoryFilter)}`);
    }
    renderCategoryFilters(catalogCategoryFilter);
    updateCatalogHeading(catalogCategoryFilter);
    updateCatalogProducts();
}

function applyProductFilters(products) {
    const normalizedTerm = catalogSearchTerm.trim().toLowerCase();
    return products.filter(product => {
        const categoryMatch = catalogCategoryFilter === 'Todos' || String(product.categoria?.nombre).toLowerCase() === catalogCategoryFilter.toLowerCase();
        const searchMatch = !normalizedTerm || [product.nombre, product.descripcion, product.categoria?.nombre]
            .some(text => String(text || '').toLowerCase().includes(normalizedTerm));
        return categoryMatch && searchMatch;
    });
}

function updateCatalogProducts() {
    const container = document.getElementById('product-list');
    if (!container) return;
    const filtered = applyProductFilters(catalogProducts);
    if (!filtered.length) {
        container.innerHTML = '<p class="notice">No se encontraron productos con esos filtros. Intente otra palabra clave o categoría.</p>';
        return;
    }
    container.innerHTML = filtered.map(buildProductCard).join('');
}

function renderSearchSuggestions(term) {
    const suggestionsElement = document.getElementById('catalog-suggestions');
    if (!suggestionsElement) return;

    const text = String(term || '').trim().toLowerCase();
    if (!text) {
        suggestionsElement.innerHTML = '';
        suggestionsElement.classList.remove('active');
        return;
    }

    const suggestions = catalogProducts
        .filter(product => {
            const searchField = `${product.nombre} ${product.categoria?.nombre || ''}`.toLowerCase();
            return searchField.startsWith(text) || searchField.includes(` ${text}`);
        })
        .slice(0, 6);

    if (!suggestions.length) {
        suggestionsElement.innerHTML = '<div class="catalog-suggestion-item"><span class="catalog-suggestion-name">No se encontraron coincidencias</span></div>';
        suggestionsElement.classList.add('active');
        return;
    }

    suggestionsElement.innerHTML = suggestions.map(product => `
        <div class="catalog-suggestion-item" data-product-id="${product.id}">
            <span class="catalog-suggestion-name">${product.nombre}</span>
            <span class="catalog-suggestion-category">${product.categoria?.nombre || 'Joyas'}</span>
        </div>
    `).join('');
    suggestionsElement.classList.add('active');

    suggestionsElement.querySelectorAll('.catalog-suggestion-item').forEach(item => {
        item.addEventListener('click', () => {
            const productId = Number(item.dataset.productId);
            const selected = catalogProducts.find(p => p.id === productId);
            if (!selected) return;
            catalogSearchTerm = selected.nombre;
            document.getElementById('catalog-search').value = selected.nombre;
            suggestionsElement.classList.remove('active');
            updateCatalogProducts();
        });
    });
}

function initializeCatalogControls() {
    catalogCategoryFilter = getCatalogFilterFromLocation();
    catalogSearchTerm = '';
    renderCategoryFilters(catalogCategoryFilter);
    updateCatalogHeading(catalogCategoryFilter);

    const searchInput = document.getElementById('catalog-search');
    const searchButton = document.getElementById('catalog-search-btn');
    const suggestionsElement = document.getElementById('catalog-suggestions');
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            catalogSearchTerm = searchInput.value;
            renderSearchSuggestions(catalogSearchTerm);
            updateCatalogProducts();
        });

        searchInput.addEventListener('focus', () => {
            renderSearchSuggestions(catalogSearchTerm);
        });
    }
    if (searchButton) {
        searchButton.addEventListener('click', () => {
            catalogSearchTerm = searchInput?.value || '';
            renderSearchSuggestions(catalogSearchTerm);
            updateCatalogProducts();
        });
    }
    document.addEventListener('click', event => {
        if (!event.target.closest('.catalog-search')) {
            suggestionsElement?.classList.remove('active');
        }
    });
}

function registerProducts(products) {
    if (!Array.isArray(products)) return;
    products.forEach(product => {
        if (product?.id != null) {
            productCache.set(Number(product.id), product);
        }
    });
}

function buildProductCard(product) {
    const image = getProductImage(product);
    return `
        <article class="product-card">
            <div class="product-thumb">
                <img src="${image}" alt="${product.nombre}" loading="lazy" onerror="this.src='${MAIN_DEFAULT_IMAGE}';">
            </div>
            <div class="product-body">
                <span class="product-category">${product.categoria?.nombre || 'Joyería de lujo'}</span>
                <h3>${product.nombre}</h3>
                <p>${product.descripcion ? product.descripcion.substring(0, 110) + '...' : 'Detalle exclusivo y elegante de colección.'}</p>
                <div class="product-actions">
                    <strong>$${Number(product.precio).toFixed(2)}</strong>
                    <div class="product-buttons">
                        <a class="btn btn-small btn-outline" href="producto.html?id=${product.id}">Ver detalle</a>
                        <button type="button" class="btn btn-small" onclick="event.stopPropagation(); addToCartById(${product.id})">Agregar</button>
                    </div>
                </div>
            </div>
        </article>
    `;
}

async function loadFeaturedProducts() {
    const container = document.getElementById('featured-products');
    if (!container) return;
    const { data, error } = await supabase.from('productos').select('*, categoria:categorias(nombre)').eq('activo', true).eq('destacado', true).limit(4);
    const products = (error || !data || !data.length) ? sampleProducts.filter(p => p.destacado).slice(0, 4) : data;
    registerProducts(products);
    container.innerHTML = products.map(buildProductCard).join('');
}

async function loadProducts() {
    const container = document.getElementById('product-list');
    if (!container) return;
    const { data, error } = await supabase.from('productos').select('*, categoria:categorias(nombre)').eq('activo', true).order('creado_en', { ascending: false });
    const products = (error || !data || !data.length) ? sampleProducts : data;
    catalogProducts = products;
    registerProducts(products);
    initializeCatalogControls();
    updateCatalogProducts();
}

function addToCart(product) {
    const existing = carrito.find(item => item.id === product.id);
    if (existing) {
        existing.cantidad = (existing.cantidad || 1) + 1;
    } else {
        carrito.push({ ...product, cantidad: 1 });
    }
    setCart(carrito);
    updateCartCount();
    alert(`✓ ${product.nombre} agregado al carrito`);
}

function addToCartById(id) {
    const product = productCache.get(Number(id)) || sampleProducts.find(p => p.id === Number(id));
    if (!product) {
        return alert('No se pudo agregar el producto al carrito. Intenta nuevamente.');
    }
    addToCart(product);
}

function updateCartCount() {
    const count = carrito.reduce((total, item) => total + (item.cantidad || 1), 0);
    const countElements = document.querySelectorAll('#cart-count');
    countElements.forEach(el => el.textContent = count);
}

async function renderCart() {
    carrito = normalizeCartItems(typeof getCartItems === "function" ? getCartItems() : []);
    updateCartCount();
    const container = document.getElementById('cart-items');
    if (!container) return;

    if (!carrito.length) {
        container.innerHTML = `
            <div class="empty-cart">
                <h2>Tu carrito est� vac�o</h2>
                <p>Explora nuestra colecci�n de joyas exclusivas y a�ade tus favoritas.</p>
                <a class="btn btn-primary" href="catalogo.html">Ver cat�logo</a>
            </div>
        `;
        document.getElementById('subtotal').textContent = '0.00';
        document.getElementById('total').textContent = '0.00';
        return;
    }

    let total = 0;
    container.innerHTML = carrito.map((item, index) => {
        const precio = Number(item.precio) * (item.cantidad || 1);
        total += precio;
        return `
            <div class="cart-item">
                <img src="${Array.isArray(item.imagenes) && item.imagenes.length ? item.imagenes[0] : MAIN_DEFAULT_IMAGE}" alt="${item.nombre}">
                <div>
                    <h3>${item.nombre}</h3>
                    <p>${item.descripcion ? item.descripcion.substring(0, 80) + '...' : 'Pieza limitada'}</p>
                    <div class="cart-meta">
                        <span>Cantidad: ${item.cantidad || 1}</span>
                        <span>Precio: $${precio.toFixed(2)}</span>
                    </div>
                    <button type="button" class="btn-link" onclick="removeFromCart(${index})">Eliminar</button>
                </div>
            </div>
        `;
    }).join('');

    document.getElementById('subtotal').textContent = total.toFixed(2);
    document.getElementById('total').textContent = total.toFixed(2);
}

function removeFromCart(index) {
    carrito.splice(index, 1);
    setCart(carrito);
    renderCart();
}

async function checkoutCart() {
    carrito = typeof getCartItems === "function" ? getCartItems() : [];
    if (!carrito.length) {
        return alert('Tu carrito est� vac�o. A�ade una pieza antes de continuar.');
    }

    const { data: sessionData } = await supabase.auth.getSession();
    const user = sessionData?.session?.user || getUserData();
    if (!user) {
        alert('Debes iniciar sesi�n para completar la compra.');
        return window.location.href = 'login.html';
    }

    const total = carrito.reduce((sum, item) => sum + Number(item.precio) * (item.cantidad || 1), 0);
    const order = await supabase.from('pedidos').insert([{ usuario_id: user.id, total, estado: 'pendiente', metodo_envio: 'Mercado Pago', direccion_envio: '' }]).select('id').single();
    if (order.error) {
        return alert('No se pudo crear el pedido. Intenta nuevamente.');
    }

    const items = carrito.map(item => ({ pedido_id: order.data.id, producto_id: item.id, cantidad: item.cantidad || 1, precio_unitario: Number(item.precio) }));
    await supabase.from('pedido_items').insert(items);
    await supabase.from('pagos').insert([{ pedido_id: order.data.id, estado: 'pendiente', monto: total, metodo: 'mercadopago' }]);

    setCart([]);
    updateCartCount();
    alert('Pedido registrado. En breve recibir�s la pasarela de pago de Mercado Pago.');
    window.location.href = 'index.html';
}

// User Authentication and Menu
async function updateAuthUi() {
    try {
        const { data: { user } } = await supabase.auth.getUser();
        
        if (user) {
            // User is logged in
            setUserData(user);
            
            // Hide login buttons, show user menu
            const authButtons = document.getElementById('auth-buttons');
            const userMenuBubble = document.getElementById('user-menu-bubble');
            
            if (authButtons) authButtons.style.display = 'none';
            if (userMenuBubble) userMenuBubble.style.display = 'block';
            
            // Get user profile info
            const { data: userData } = await supabase
                .from('usuarios')
                .select('full_name, email, avatar_url, role')
                .eq('id', user.id)
                .single();
            
            const displayName = userData?.full_name || user.user_metadata?.full_name || 'Usuario';
            const userEmail = user.email;
            const isAdmin = userData?.role === 'admin';
            
            // Update bubble display
            document.getElementById('bubbleUserName').textContent = displayName;
            document.getElementById('bubbleUserEmail').textContent = userEmail;
            
            // Show admin link if admin
            const adminLink = document.getElementById('adminLink');
            if (adminLink && isAdmin) {
                adminLink.style.display = 'flex';
            }
            
            // Setup bubble menu
            setupUserBubbleMenu();
        } else {
            // User is not logged in
            const authButtons = document.getElementById('auth-buttons');
            const userMenuBubble = document.getElementById('user-menu-bubble');
            
            if (authButtons) authButtons.style.display = 'flex';
            if (userMenuBubble) userMenuBubble.style.display = 'none';
        }
    } catch (error) {
        console.error('Error updating auth UI:', error);
    }
}

function setupUserBubbleMenu() {
    const bubbleBtn = document.getElementById('userBubbleBtn');
    const dropdown = document.getElementById('userBubbleDropdown');
    const logoutBtn = document.getElementById('logoutBubbleBtn');
    
    if (bubbleBtn) {
        bubbleBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            dropdown.classList.toggle('active');
        });
    }
    
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            try {
                await supabase.auth.signOut();
                window.location.href = 'index.html';
            } catch (error) {
                console.error('Error logging out:', error);
            }
        });
    }
    
    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.user-menu-bubble')) {
            if (dropdown) dropdown.classList.remove('active');
        }
    });
}

document.addEventListener('DOMContentLoaded', async () => {
    carrito = typeof getCartItems === "function" ? getCartItems() : [];
    updateCartCount();
    await updateAuthUi();
    await loadFeaturedProducts();
    await loadProducts();
    if (document.getElementById('cart-items')) {
        await renderCart();
    }
});


