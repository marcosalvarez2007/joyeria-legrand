// supabase/functions/refund-payment/index.ts
//
// Reembolsa el pago de un pedido en Mercado Pago y actualiza el estado
// en la base de datos. Corre en el servidor de Supabase (Deno), nunca
// en el navegador, porque necesita el ACCESS TOKEN secreto de Mercado Pago.
//
// Deploy:
//   supabase functions deploy refund-payment
// Secrets necesarios (Project Settings > Edge Functions > Secrets, o CLI):
//   supabase secrets set MP_ACCESS_TOKEN=APP_USR-xxxxxxxx
// (SUPABASE_URL, SUPABASE_ANON_KEY y SUPABASE_SERVICE_ROLE_KEY ya existen
// automáticamente en el entorno de toda función).

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const MP_ACCESS_TOKEN = Deno.env.get("MP_ACCESS_TOKEN")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Método no permitido" }, 405);

  try {
    // --- 0. Autenticación: solo un admin logueado puede llamar esta función ---
    const authHeader = req.headers.get("Authorization") ?? "";
    const supabaseUser = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: userData, error: userError } = await supabaseUser.auth.getUser();
    if (userError || !userData?.user) {
      return json({ error: "No autenticado" }, 401);
    }

    // Cliente con service role: puede leer/escribir sin las restricciones de RLS
    const db = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { data: perfil } = await db
      .from("usuarios")
      .select("role")
      .eq("id", userData.user.id)
      .single();

    if (perfil?.role !== "admin") {
      return json({ error: "No tenés permisos de administrador" }, 403);
    }

    const { pedido_id, motivo } = await req.json();
    if (!pedido_id) return json({ error: "Falta pedido_id" }, 400);

    // --- 1. Buscar ID del pago (pedido -> pago) ---
    const { data: pago, error: pagoError } = await db
      .from("pagos")
      .select("id, estado, mp_payment_id, monto, pedido_id")
      .eq("pedido_id", pedido_id)
      .single();

    if (pagoError || !pago) {
      return json({ error: "No se encontró el pago de este pedido" }, 404);
    }
    if (!pago.mp_payment_id) {
      return json({ error: "Este pago no tiene un ID de Mercado Pago asociado" }, 400);
    }
    if (pago.estado === "reembolsado") {
      return json({ error: "Este pago ya fue reembolsado" }, 400);
    }

    const { data: pedido } = await db
      .from("pedidos")
      .select("id, estado")
      .eq("id", pedido_id)
      .single();

    if (!pedido) return json({ error: "No se encontró el pedido" }, 404);

    // --- 2. Consultar Mercado Pago (fuente de verdad, no confiar solo en la DB) ---
    const mpRes = await fetch(`https://api.mercadopago.com/v1/payments/${pago.mp_payment_id}`, {
      headers: { Authorization: `Bearer ${MP_ACCESS_TOKEN}` },
    });
    const mpPayment = await mpRes.json();
    if (!mpRes.ok) {
      return json({ error: "No se pudo consultar el pago en Mercado Pago", detalle: mpPayment }, 502);
    }

    // --- 3. ¿Está aprobado? ---
    if (mpPayment.status !== "approved") {
      return json(
        { error: `El pago no está aprobado en Mercado Pago (estado: ${mpPayment.status}). No corresponde devolución.` },
        400
      );
    }

    // --- 4. ¿Corresponde la devolución? ---
    // Reglas de negocio: no reembolsamos pedidos ya entregados desde acá
    // (esos se manejan manualmente / logística de devolución física).
    if (pedido.estado === "entregado") {
      return json(
        { error: "El pedido ya fue entregado. Esta devolución requiere gestión manual (logística de devolución)." },
        400
      );
    }

    // --- 5. Ejecutar el reembolso en Mercado Pago ---
    const refundRes = await fetch(
      `https://api.mercadopago.com/v1/payments/${pago.mp_payment_id}/refunds`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${MP_ACCESS_TOKEN}`,
          "Content-Type": "application/json",
          // Evita reembolsos duplicados si el request se reintenta
          "X-Idempotency-Key": `refund-${pedido_id}-${pago.mp_payment_id}`,
        },
        // Body vacío = reembolso TOTAL. Para reembolso parcial: { amount: 123.45 }
        body: JSON.stringify({}),
      }
    );
    const refundData = await refundRes.json();

    if (!refundRes.ok) {
      return json({ error: "Mercado Pago rechazó el reembolso", detalle: refundData }, 502);
    }

    // --- 6. Marcar orden como reembolsada ---
    await db
      .from("pagos")
      .update({ estado: "reembolsado", mp_status: "refunded" })
      .eq("id", pago.id);

    await db
      .from("pedidos")
      .update({ estado: "cancelado" })
      .eq("id", pedido_id);

    // Devolver stock de los productos del pedido (si aún no se había devuelto)
    const { data: items } = await db
      .from("pedido_items")
      .select("producto_id, cantidad")
      .eq("pedido_id", pedido_id);

    for (const item of items ?? []) {
      await db.rpc("incrementar_stock", {
        p_producto_id: item.producto_id,
        p_cantidad: item.cantidad,
      });
    }

    console.log(`Reembolso OK - pedido ${pedido_id} - motivo: ${motivo ?? "no especificado"}`);

    return json({ ok: true, refund: refundData });
  } catch (err) {
    console.error(err);
    return json({ error: "Error interno procesando el reembolso" }, 500);
  }
});
