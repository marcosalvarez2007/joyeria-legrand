-- ============================================================
-- Migración: soporte de reembolsos
-- Ejecutar en el SQL Editor de Supabase (una sola vez)
-- ============================================================

-- 1. Permitir el estado 'reembolsado' en pagos
alter table pagos drop constraint if exists pagos_estado_check;
alter table pagos add constraint pagos_estado_check
  check (estado in ('pendiente','aprobado','rechazado','reembolsado'));

-- 2. Función para devolver stock sin necesidad de borrar el pedido_item
--    (la usa la Edge Function refund-payment al reembolsar)
create or replace function incrementar_stock(p_producto_id bigint, p_cantidad integer)
returns void
language plpgsql
security definer set search_path = public
as $$
begin
  update productos set stock = stock + p_cantidad where id = p_producto_id;
end;
$$;

-- Nota: incrementar_stock corre con permisos elevados (security definer),
-- por eso solo debe ser invocada desde la Edge Function con la
-- service_role key, nunca expuesta directamente al cliente.
revoke all on function incrementar_stock(bigint, integer) from public, anon, authenticated;
